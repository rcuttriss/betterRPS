const socket = io();

// Function to join a room
function joinRoom(roomName) {
  console.log(`joining room ${roomName}`);
  socket.emit("joinRoom", roomName);
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = "Joining Room...";
}

socket.on("updateRooms", (rooms) => {
  console.log(rooms);
  const roomList = document.querySelector(".room-list");
  for (let roomName in rooms) {
    // Create a new <li> element
    const li = document.createElement("li");
    // Set the text content of the <li> to the room name
    li.textContent = roomName;
    // Set onclick
    li.onclick = function () {
      joinRoom(roomName);
    };
    // Append the <li> to the .room-list element
    roomList.appendChild(li);
  }
});

socket.on("roomJoined", (roomName) => {
  console.log(`Joined room: ${roomName}`);
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = `Joined Room ${roomName}`;
  let choicesCont = document.querySelector(".choices");
  choicesCont.style.display = "block";
});

socket.on("roomFull", () => {
  console.log("Room is full!");
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = "Room is full!";
});

socket.on("opponentChoice", () => {
  const str = "Opponent has chosen!";
  console.log(str);
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = str;
});

socket.on("opponentLeft", () => {
  const str = "Opponent left the room.";
  console.log(str);
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = str;
  // Update the UI to indicate the opponent has left.
});

socket.on("result", (winner) => {
  console.log(winner);
  let str;
  if (winner === "DRAW") {
    str = "It’s a Draw!";
    console.log(str);
  } else if (winner === socket.id) {
    str = "You Win!";
    console.log(str);
  } else {
    str = "You Lose!";
    console.log(str);
  }
  let feedbackLine = document.querySelector(".feedback-line");
  feedbackLine.innerText = str;
});

function makeChoice(choice) {
  socket.emit("choice", choice);
}

// Call joinRoom with the desired room name when you want to join.
// For example: joinRoom('room1');
